package solution;

import java.io.*;
import org.json.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.List;

import baseclasses.CabinCrew;
import baseclasses.Crew;
import baseclasses.DataLoadingException;
import baseclasses.ICrewDAO;
import baseclasses.Pilot;

/**
 * The CrewDAO is responsible for loading data from JSON-based crew files It
 * contains various methods to help the scheduler find the right pilots and
 * cabin crew
 */
public class CrewDAO implements ICrewDAO {
	private ArrayList<CabinCrew> cabin = new ArrayList<CabinCrew>();
	private ArrayList<Pilot> pilots = new ArrayList<Pilot>();

	/**
	 * Loads the crew data from the specified file, adding them to the currently
	 * loaded crew Multiple calls to this function, perhaps on different files,
	 * would thus be cumulative
	 * 
	 * @param p A Path pointing to the file from which data could be loaded
	 * @throws DataLoadingException if anything goes wrong. The exception's "cause"
	 *                              indicates the underlying exception
	 */
	@Override
	public void loadCrewData(Path p) throws DataLoadingException {
		try {
			BufferedReader reader = Files.newBufferedReader(p);

			//read the file line by line
			String line = "";
			String json = "";

			while ((line = reader.readLine()) != null) {
				json = json + line;
			}

			JSONObject data = new JSONObject(json); // convert string to JSON Object
			JSONArray aircrew = data.getJSONArray("pilots"); // get pilot data
			JSONArray cabinstaff = data.getJSONArray("cabincrew"); // get cabin crew

			// process pilot data and put pilot objects in list
			for (int i = 0; i < aircrew.length(); i++) {
				Pilot pilot = new Pilot();
				JSONObject temp = aircrew.getJSONObject(i);
				pilot.setForename(temp.getString("forename"));
				pilot.setSurname(temp.getString("surname"));
				pilot.setHomeBase(temp.getString("homebase"));

				String rank = temp.getString("rank");
				Pilot.Rank rnk = Pilot.Rank.valueOf(rank);
				pilot.setRank(rnk);
				JSONArray types = temp.getJSONArray("typeRatings");

				for (int j = 0; j < types.length(); j++) {
					pilot.setQualifiedFor(types.getString(j));
				}
				if (!pilots.contains(pilot)) {
					pilots.add(pilot);
				}
			}

			// Cabin Staff
			for (int i = 0; i < cabinstaff.length(); i++) {
				CabinCrew crew = new CabinCrew();
				JSONObject temp = cabinstaff.getJSONObject(i);

				String fname = temp.getString("forename");
				crew.setForename(fname);
				crew.setSurname(temp.getString("surname"));
				crew.setHomeBase(temp.getString("homebase"));

				JSONArray types = temp.getJSONArray("typeRatings");

				for (int j = 0; j < types.length(); j++) {
					crew.setQualifiedFor(types.getString(j));
				}

				if (!cabin.contains(crew)) {
					cabin.add(crew);
				}
			}

		}
		catch (IOException | JSONException e) { // was there a problem reading this file?
			throw new DataLoadingException(e);

		}

	}

	/**
	 * Returns a list of all the cabin crew based at the airport with the specified
	 * airport code
	 * 
	 * @param airportCode the three-letter airport code of the airport to check for
	 * @return a list of all the cabin crew based at the airport with the specified
	 *         airport code
	 */
	@Override
	public List<CabinCrew> findCabinCrewByHomeBase(String airportCode) {
		List<CabinCrew> temp = new ArrayList<CabinCrew>();
		for (CabinCrew c : cabin) {
			if (c.getHomeBase().equals(airportCode)) {
				if (!temp.contains(c)) {
					temp.add(c);
				}
			}
		}

		return temp;
	}

	/**
	 * Returns a list of all the cabin crew based at a specific airport AND
	 * qualified to fly a specific aircraft type
	 * 
	 * @param typeCode    the type of plane to find cabin crew for
	 * @param airportCode the three-letter airport code of the airport to check for
	 * @return a list of all the cabin crew based at a specific airport AND
	 *         qualified to fly a specific aircraft type
	 */
	@Override
	public List<CabinCrew> findCabinCrewByHomeBaseAndTypeRating(String typeCode, String airportCode) {
		List<CabinCrew> temp = new ArrayList<CabinCrew>();
		for (CabinCrew c : cabin) {
			if (c.getHomeBase().equals(airportCode) && c.getTypeRatings().contains(typeCode)) {
				if (!temp.contains(c)) {
					temp.add(c);
				}
			}
		}
		return temp;
	}

	/**
	 * Returns a list of all the cabin crew currently loaded who are qualified to
	 * fly the specified type of plane
	 * 
	 * @param typeCode the type of plane to find cabin crew for
	 * @return a list of all the cabin crew currently loaded who are qualified to
	 *         fly the specified type of plane
	 */
	@Override
	public List<CabinCrew> findCabinCrewByTypeRating(String typeCode) {
		List<CabinCrew> temp = new ArrayList<CabinCrew>();
		for (CabinCrew c : cabin) {
			if (c.getTypeRatings().contains(typeCode)) {
				if (!temp.contains(c)) {
					temp.add(c);
				}
			}
		}
		return temp;
	}

	/**
	 * Returns a list of all the pilots based at the airport with the specified
	 * airport code
	 * 
	 * @param airportCode the three-letter airport code of the airport to check for
	 * @return a list of all the pilots based at the airport with the specified
	 *         airport code
	 */
	@Override
	public List<Pilot> findPilotsByHomeBase(String airportCode) {
		List<Pilot> temp = new ArrayList<Pilot>();
		for (Pilot pi : pilots) {
			if (pi.getHomeBase().equals(airportCode)) {
				if (!temp.contains(pi)) {
					temp.add(pi);
				}
			}
		}
		return temp;
	}

	/**
	 * Returns a list of all the pilots based at a specific airport AND qualified to
	 * fly a specific aircraft type
	 * 
	 * @param typeCode    the type of plane to find pilots for
	 * @param airportCode the three-letter airport code of the airport to check for
	 * @return a list of all the pilots based at a specific airport AND qualified to
	 *         fly a specific aircraft type
	 */
	@Override
	public List<Pilot> findPilotsByHomeBaseAndTypeRating(String typeCode, String airportCode) {
		List<Pilot> temp = new ArrayList<Pilot>();
		for (Pilot pi : pilots) {
			if (pi.getHomeBase().equals(airportCode) && pi.getTypeRatings().contains(typeCode)) {
				if (!temp.contains(pi)) {
					temp.add(pi);
				}
			}
		}
		return temp;
	}

	/**
	 * Returns a list of all the pilots currently loaded who are qualified to fly
	 * the specified type of plane
	 * 
	 * @param typeCode the type of plane to find pilots for
	 * @return a list of all the pilots currently loaded who are qualified to fly
	 *         the specified type of plane
	 */
	@Override
	public List<Pilot> findPilotsByTypeRating(String typeCode) {
		List<Pilot> temp = new ArrayList<Pilot>();
		for (Pilot pi : pilots) {
			if (pi.getTypeRatings().contains(typeCode)) {
				if (!temp.contains(pi)) {
					temp.add(pi);
				}
			}
		}
		return temp;
	}

	/**
	 * Returns a list of all the cabin crew currently loaded
	 * 
	 * @return a list of all the cabin crew currently loaded
	 */
	@Override
	public List<CabinCrew> getAllCabinCrew() {
		return cabin;
	}

	/**
	 * Returns a list of all the crew, regardless of type
	 * 
	 * @return a list of all the crew, regardless of type
	 */
	@Override
	public List<Crew> getAllCrew() {
		List<Crew> all = new ArrayList<Crew>();

		all.addAll(pilots);
		all.addAll(cabin);
		
		return all;
	}

	/**
	 * Returns a list of all the pilots currently loaded
	 * 
	 * @return a list of all the pilots currently loaded
	 */
	@Override
	public List<Pilot> getAllPilots() {
		return pilots;
	}

	@Override
	public int getNumberOfCabinCrew() {
		return cabin.size();
	}

	/**
	 * Returns the number of pilots currently loaded
	 * 
	 * @return the number of pilots currently loaded
	 */
	@Override
	public int getNumberOfPilots() {
		return pilots.size();
	}

	/**
	 * Unloads all of the crew currently loaded, ready to start again if needed
	 */
	@Override
	public void reset() {
		cabin.clear();
		pilots.clear();

	}

}