package solution;
import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.time.Duration;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import baseclasses.Route;
import baseclasses.DataLoadingException;
import baseclasses.IRouteDAO;


/**
 * The RouteDAO parses XML files of route information, each route specifying
 * where the airline flies from, to, and on which day of the week
 */
public class RouteDAO implements IRouteDAO {
	private ArrayList<Route> routes = new ArrayList<Route>();
		
	 
	
	/**
	 * Finds all flights that depart on the specified day of the week
	 * @param dayOfWeek A three letter day of the week, e.g. "Tue"
	 * @return A list of all routes that depart on this day
	 */
	@Override
	public List<Route> findRoutesByDayOfWeek(String dayOfWeek) {
		// TODO Auto-generated method stub
		ArrayList<Route> foundRouteList = new ArrayList<Route>();
		
		for (Route route : this.routes) {
			if (route.getDayOfWeek().equals(dayOfWeek))
				foundRouteList.add(route);
		}
		return foundRouteList;
	}

	/**
	 * Finds all of the flights that depart from a specific airport on a specific day of the week
	 * @param airportCode the three letter code of the airport to search for, e.g. "MAN"
	 * @param dayOfWeek the three letter day of the week code to search for, e.g. "Tue"
	 * @return A list of all routes from that airport on that day
	 */
	@Override
	public List<Route> findRoutesByDepartureAirportAndDay(String airportCode, String dayOfWeek) {

		ArrayList<Route> foundRouteList = new ArrayList<Route>();
		
		for (Route route : this.routes) {
			if (route.getDayOfWeek().equals(dayOfWeek) && route.getDepartureAirportCode().equals(airportCode))
				foundRouteList.add(route);
		}
		return foundRouteList;
	}

	/**
	 * Finds all of the flights that depart from a specific airport
	 * @param airportCode the three letter code of the airport to search for, e.g. "MAN"
	 * @return A list of all of the routes departing the specified airport
	 */
	@Override
	public List<Route> findRoutesDepartingAirport(String airportCode) {

		ArrayList<Route> foundRouteList = new ArrayList<Route>();
		
		for (Route route : this.routes) {
			if (route.getDepartureAirportCode().equals(airportCode))
				foundRouteList.add(route);
		}
		return foundRouteList;
	}

	/**
	 * Finds all of the flights that depart on the specified date
	 * @param date the date to search for
	 * @return A list of all routes that depart on this date
	 */
	@Override
	public List<Route> findRoutesbyDate(LocalDate date) {
		ArrayList<Route> foundRouteList = new ArrayList<Route>();
		
		for (Route route : this.routes) {
			if (route.getDayOfWeek().toUpperCase().contains(date.getDayOfWeek().toString())) {
				foundRouteList.add(route);
			}
		}
		return foundRouteList;
	}

	/**
	 * Returns The full list of all currently loaded routes
	 * @return The full list of all currently loaded routes
	 */
	@Override
	public List<Route> getAllRoutes() {
		return routes;
	}

	/**
	 * Returns The number of routes currently loaded
	 * @return The number of routes currently loaded
	 */
	@Override
	public int getNumberOfRoutes() {
		return routes.size();
	}

	/**
	 * Loads the route data from the specified file, adding them to the currently loaded routes
	 * Multiple calls to this function, perhaps on different files, would thus be cumulative
	 * @param p A Path pointing to the file from which data could be loaded
	 * @throws DataLoadingException if anything goes wrong. The exception's "cause" indicates the underlying exception
	 */
	@Override
	public void loadRouteData(Path arg0) throws DataLoadingException {
		try {
			DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	        String p = arg0.toString();
	        Document doc = db.parse(p);
	        Element root = doc.getDocumentElement(); // getDocumentElement = get root element
	        
	        NodeList routeNodes = root.getChildNodes();
	        for(int i=0;i<routeNodes.getLength();i++) {
	        	Node route = routeNodes.item(i);
	        	if(route.getNodeName().equals("Route")) {
	        		Route newRoute = new Route();
	        		NodeList routeData = route.getChildNodes();
	        		for(int z=0;z<routeData.getLength();z++) {
	        			Node a = routeData.item(z);
	        			if (a.getNodeName().equals("FlightNumber")) {
	        				try {
	        					newRoute.setFlightNumber(Integer.parseInt(a.getChildNodes().item(0).getNodeValue()));
	        					System.out.println(Integer.parseInt(a.getChildNodes().item(0).getNodeValue()));
	        				}
	        				catch (IllegalArgumentException iae) {
	        					throw new DataLoadingException(iae);
	        				}
	        			}
	        			if (a.getNodeName().equals("DayOfWeek")) {
	        				newRoute.setDayOfWeek(a.getChildNodes().item(0).getNodeValue());
	        				System.out.println(a.getChildNodes().item(0).getNodeValue());
	        			}
	        			if (a.getNodeName().equals("DepartureTime")) {
	        				newRoute.setDepartureTime(LocalTime.parse(a.getChildNodes().item(0).getNodeValue()));
	        				System.out.println(a.getChildNodes().item(0).getNodeValue());
	        			}
	        			if (a.getNodeName().equals("DepartureAirport")) {
	        				newRoute.setDepartureAirport(a.getChildNodes().item(0).getNodeValue());
	        				System.out.println(a.getChildNodes().item(0).getNodeValue());
	        			}
	        			if (a.getNodeName().equals("DepartureAirportCode")) {
	        				newRoute.setDepartureAirportCode(a.getChildNodes().item(0).getNodeValue());
	        				System.out.println(a.getChildNodes().item(0).getNodeValue());
	        			}
	        			if (a.getNodeName().equals("ArrivalTime")) {
	        				newRoute.setArrivalTime(LocalTime.parse(a.getChildNodes().item(0).getNodeValue()));
	        				System.out.println(a.getChildNodes().item(0).getNodeValue());
	        			}
	        			if (a.getNodeName().equals("ArrivalAirport")) {
	        				newRoute.setArrivalAirport(a.getChildNodes().item(0).getNodeValue());
	        				System.out.println(a.getChildNodes().item(0).getNodeValue());
	        		    }
	        			if (a.getNodeName().equals("ArrivalAirportCode")) {
	        				newRoute.setArrivalAirportCode(a.getChildNodes().item(0).getNodeValue());
	        				System.out.println(a.getChildNodes().item(0).getNodeValue());
	        			}
	        			if (a.getNodeName().equals("Duration")) {
	        				newRoute.setDuration(Duration.parse(a.getChildNodes().item(0).getNodeValue())); 
	        				System.out.println(a.getChildNodes().item(0).getNodeValue());
	        			}
	        		
	        			}
	        		
	        			routes.add(newRoute);
	        		}
	        	
	        	}
	        
			} 
			catch(IOException | ParserConfigurationException | SAXException ioe) {
				throw new DataLoadingException(ioe);
			}

	}

	/**
	 * Unloads all of the crew currently loaded, ready to start again if needed
	 */
	@Override
	public void reset() {
		// TODO Auto-generated method stub
		routes.clear();
	}

	}
